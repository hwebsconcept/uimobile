<?php
require_once('connect.php');
session_start();
if (!isset ($_SESSION['matric']))
{
    $go="index.html";
    header("Location:".$go);
}
$matric = $_SESSION['matric'];
$friend= $dbh->prepare("SELECT * FROM friends WHERE matric=:matric AND status = 1 ORDER BY id DESC");
$friend->bindParam(':matric', $matric);
$friend->execute();
while ($friends=$friend->fetch(PDO::FETCH_ASSOC))
{
    $friend_detail= $dbh->prepare("SELECT * FROM users WHERE matric=:matric");
    $friend_detail->bindParam(':matric', $friends['receiverMatric']);
    $friend_detail->execute();
    $friend_details=$friend_detail->fetch(PDO::FETCH_ASSOC);
?>
    <a href="tel:<?php echo $friend_details['phone'] ?>">
        <div class="col-md-12 col-sm-12 col-xs-12" style="padding:10px; border-bottom:1px solid #ccc; color:#434343;">
            <img src="admin/<?php echo $friend_details['img'] ?>" class="img-responsive img-circle pull-left" style="max-width:45px;"/>
            <div align="right">
                <b><?php echo $friend_details['name'] ?></b><br>
                <?php echo $friend_details['phone'] ?>
            </div>
        </div>
    </a>
<?php
}
?>

